#include<stdio.h>
int main(){
    int number;
    printf("Enter a number:");
    scanf("%d",&number);
    printf("you entered:%d\n",number);
    return 0;
}

